
import main.Collections;
import main.Member;
import main.Employee;
import java.util.Date;



public class Librarian extends Employee {
public Librarian (String name, String address, Date dateOfBirth, String email, String socialSecurityNumber, String empType, String employeeNumber){
    super(employeeNumber, name, address, dateOfBirth, email, socialSecurityNumber, empType);
}


    public String getMemberID(Member member){
        return member.getMemberID();
    }
    public void setMemberID(Member member){
        setMemberID(member);
    }
    public String getCollectionID(Collections collection){
        return collection.getCollectionID();
    }

    public String getBookISBN(Books book){
        return book.getISBN();
    }
    
}


