package main;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.stage.Stage;

public class UpdateMemberController {
    @FXML
    private TextField nameField;
    @FXML
    private TextField addressField;
    @FXML
    private TextField dobField;
    @FXML
    private TextField emailField;
    @FXML
    private TextField ssnField;
    @FXML
    private TextField memberField;
    @FXML
    private Button nextButton;
    @FXML
    private Button saveButton;
    @FXML
    private RadioButton externalButton;
    @FXML
    private RadioButton studentButton;
    @FXML
    private RadioButton professorButton;
    
    @FXML
    private TextField MemberID;
    private String ID;
    
    private static String currType;
    
    
    
    private List<Member> memberlist;
    
    public void setlist(List<Member> memberlist) {
        this.memberlist = memberlist;
    }
    
    public void initialize() {
    memberlist = new ArrayList<>();
    externalButton.setOnAction(event -> externalButtonClicked());
    studentButton.setOnAction(event -> studentButtonClicked());
    professorButton.setOnAction(event -> professorButtonClicked());
try {
            File members = new File("members.txt");

            if(members.exists()) {
                BufferedReader reader = new BufferedReader(new FileReader(members));
                String curr;
                while((curr = reader.readLine()) != null) {
                    String[] memberInfo = curr.split("\t");
                    String memID = memberInfo[0].strip();
                    String email = memberInfo[4];
                    String origDob = memberInfo[3];
                    String address = memberInfo[2];
                    String memberType = memberInfo[6];
                    String name = memberInfo[1];
                    String ssn = memberInfo[5];

                    Date newdob = new Date(0);
                    Member mem = new Member(name, address, newdob, email, ssn, memID, memberType);
                    memberlist.add(mem);
                }

                reader.close();
            }
        } catch (IOException e) {
            System.out.println("There was an error trying to update member " + MemberID.getText());
            e.printStackTrace();
        }
         for (Member mem : memberlist){
            System.out.println(mem.getMemberID());
            
        }
    }
    
  public void externalButtonClicked() {
      currType = "external";
   }
  
    public void studentButtonClicked() {
      currType = "student";
   }
    
     public void professorButtonClicked() {
      currType = "professor";
   }
  

    
 public void saveButtonClicked() {
     Member membertoupdate = null;
        for (Member mem : memberlist){
            System.out.println(mem.getMemberID());
            ID = MemberID.getText();
            System.out.println(ID);
            if (ID.equals(mem.getMemberID())){
                membertoupdate = mem;
            }
        }
        if (membertoupdate == null) {
            System.out.println("There was no member found with ID");
        }
        else {
            String name = nameField.getText();
            String address = addressField.getText();
            Date dob = convertTextFieldToDate(dobField.getText());
            String email = emailField.getText();
            String ssn = ssnField.getText();
            String MemType = currType;
            File members = null;
        File temp = null;

        BufferedReader reader = null;
        BufferedWriter writer = null;
        //BufferedWriter checkoutWriter = null;

        try {
            members = new File("members.txt");
            temp = new File("tempMem.txt");
            //checkouts = new File("CheckedOutItems.txt");

            reader = new BufferedReader(new FileReader(members));
            writer = new BufferedWriter(new FileWriter(temp));
            //checkoutWriter = new BufferedWriter(new FileWriter(checkouts, true));

            String curr;
            boolean found = false;

            while ((curr = reader.readLine()) != null) {
                String[] memberInfo = curr.split("\t");
                String memID = memberInfo[0].strip();

                if(memID.equals(MemberID.getText())) {
                    found = true;

                    String updatedInfo = String.format("%s\t%s\t%s\t%s\t%s\t%s\t%s\n", MemberID.getText(), name, address, dob, email, ssn, MemType);
                    membertoupdate.setName(name);
                    membertoupdate.setAddress(address);
                    membertoupdate.setDateOfBirth(dob);
                    membertoupdate.setEmail(email);
                    membertoupdate.setSocialSecurityNumber(ssn);
                    membertoupdate.setMemberType(MemType);

                    writer.write(updatedInfo);
                } else {
                    if(!memID.equals(MemberID.getText())) {
                        writer.write(curr);
                        writer.newLine();
                    }
                }
            }

            if(!found) {
                System.out.println("Member not found.");
            } else {
                System.out.println("Member information updated successfully.");
            }
        } catch (IOException e) {
            System.out.println("There was an error trying to update member " + MemberID.getText());
        } finally {
            try {
                reader.close();
                writer.close();
                //checkoutWriter.close();
                members.delete();
                temp.renameTo(members);
            } catch (IOException e) {
                System.out.println("There was an error trying to close the files.");
            }
        }
        }
 }

  private Date convertTextFieldToDate(String dateString) {

        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        dateFormat.setLenient(false);
        Date date = null;
        boolean validDate = false;
        dateString = dobField.getText();
        try {
            date = dateFormat.parse(dateString);
            System.out.println("Parsed Date: " + date);
            validDate = true;
            
            // Do something with the parsed date
        } catch (ParseException e) {
            System.out.println("Invalid date format. Please enter date of birth in MM/dd/yyyy format.");
            // Handle the parse exception
        }
    return date;
   }
    
    
    public void switchToScene1(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Scene1.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    
       /* public void switchToScene10(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Scene10.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
        ID = MemberID.getText();
    }*/
    // Other methods for switching scenes, etc.
}
