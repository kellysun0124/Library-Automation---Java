
package main;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;



public class CheckInController {
    
private List<Member> memberlist;
    @FXML
    private TextField collectionIDTextField;
    @FXML
    private Button checkinButton;
    @FXML
    private TextField MemberID;
    private String ID;
    
    private String collectionID;
    
    


    
    public void initialize() {
    checkinButton.setOnAction(event -> checkinButtonClicked());
    memberlist = new ArrayList<>();
        try {
            File members = new File("members.txt");

            if(members.exists()) {
                BufferedReader reader = new BufferedReader(new FileReader(members));
                String curr;
                while((curr = reader.readLine()) != null) {
                    String[] memberInfo = curr.split("\t");
                    String memID = memberInfo[0].strip();
                    String email = memberInfo[4];
                    String origDob = memberInfo[3];
                    String address = memberInfo[2];
                    String memberType = memberInfo[6];
                    String name = memberInfo[1];
                    String ssn = memberInfo[5];

                    Date newdob = new Date(0);
                    Member mem = new Member(name, address, newdob, email, ssn, memID, memberType);
                    memberlist.add(mem);
                }

                reader.close();
            }
        } catch (IOException e) {
            System.out.println("There was an error trying to update member " + MemberID.getText());
            e.printStackTrace();
        }
         for (Member mem : memberlist){
            System.out.println(mem.getMemberID());
            
        }
    }
    
     public void checkinButtonClicked() {
     Member member = null;
        for (Member mem : memberlist){
            System.out.println(mem.getMemberID());
            ID = MemberID.getText();
            System.out.println(ID);
            if (ID.equals(mem.getMemberID())){
                member = mem;
            }
        }
        if (member == null) {
            System.out.println("There was no member found with ID");
        }
        else {
            collectionID = collectionIDTextField.getText();
            File myFile = new File("CheckedOutItems.txt");
            File tempFile = new File("tempCheckedIn.txt");

            try {
                BufferedReader reader = new BufferedReader(new FileReader(myFile));
                BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));
                
                String lineToRemove = collectionID;
                String currentLine;
                boolean found = false;

                while ((currentLine = reader.readLine()) != null) {
                    String[] currline = currentLine.split("\t");
                    String memID = currline[0];
                    String col1 = currline[1];
                    String col2 = currline[2];
                    String col3 = currline[3];
                    String col4 = currline[4];
                    String col5 = currline[5];
                    int i = 0;
                    
                    
                    for(String col : currline) {
                        if(i>0 &&   col.equals(collectionID)) {
                            member.setCheckedOut(i, "0");
                            writer.write("0\t");
                            found = true;
                        } else {
                            writer.write(col + "\t");
                        }
                        i++;
                    }

                    writer.newLine();
                }

                if (!found) {
                    System.out.println("Book not found.");
                } else {
                    System.out.println("Book returned successfully.");
                }

                reader.close();
                writer.close();


                if (!myFile.delete()) {
                    System.out.println("Could not delete the original file.");
                }
                if (!tempFile.renameTo(myFile)) {
                    System.out.println("Could not rename the temporary file.");
                }
                
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
     
       public void switchToScene1(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Scene1.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }  
     
}