package main;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class NewCollectionController {
    @FXML
    private TextField collectionIDField;
    @FXML
    private TextField titleField;
    @FXML
    private TextField publisherField;
    @FXML
    private TextField genreField;
    @FXML
    private TextField typeField;
    @FXML
    private TextField isbnField;
    @FXML
    private TextField issnField;
    @FXML
    private TextField authorField;
    @FXML
    private Button saveButton;
    
    private static String currCollection;
    
    private List<Collections> collectionsList;

    @FXML
    public void initialize() {
        collectionsList = new ArrayList<>();
    }
    
    public void setcurr(String curr) {
        this.currCollection = curr;
    }
    
    public void saveButtonClicked() {
        System.out.println(currCollection);
       if(currCollection != null) {
            String ID = GetIDs.returnID("Collectiondatabase.txt");
            String title = titleField.getText();
            String publisher = publisherField.getText();
            String genre = genreField.getText();
            String type = currCollection;
            String itemInfo = title + "," + publisher + "," + genre + "," + type + "\n";
            String author = null;
            String isbn = null;
            String issn = null;
            switch (currCollection) {
                case "DVDs":
                    isbn = isbnField.getText();
                    itemInfo = ID + "," + isbn + "," + itemInfo + "\n";
                break;
                case "Books":
                    isbn = isbnField.getText();
                    author = authorField.getText();
                    itemInfo = ID + "," + isbn + "," + author + "," + itemInfo + "\n";
                break;
                case "Journals":
                    issn = issnField.getText();
                    author = authorField.getText();
                    itemInfo = ID + "," + issn + "," + author + "," + itemInfo + "\n";
                break;
                case "Newspapers":
                    issn = issnField.getText();
                    itemInfo = ID + "," + issn + "," + itemInfo + "\n";
                break;
            }
            try {
            SaveToFile.save(itemInfo, "Collectiondatabase.txt");
            showSuccessAlert();
            } catch (Exception e) {
                showErrorAlert();
            }
            } else {
            System.out.println("The collection type doesn't exist.");
        }
    }

    private void showSuccessAlert() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText(null);
        alert.setContentText("New collection Successfully Saved to File.");
        alert.showAndWait();
    }

    private void showErrorAlert() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText("Failed to save collection information.");
        alert.showAndWait();
    }

    
    public void switchToBooksFXML(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("BookFXML.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
        currCollection = "Books";
    }

    public void switchToDVDFXML(ActionEvent event) throws IOException {
        currCollection = "DVDs";
        Parent root = FXMLLoader.load(getClass().getResource("DVDFXML.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    
    public void switchToJournalFXML(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("JournalFXML.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
        currCollection = "Journals";
    }
    
    public void switchToNewspaperFXML(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("NewspaperFXML.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
        currCollection = "Newspapers";
    }
    
    public void switchToScene1(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Scene1.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    
        public void switchToScene4(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Scene4.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    // Other methods for switching scenes, etc.
}