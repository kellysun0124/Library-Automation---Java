package main;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.RadioButton;
import javafx.stage.Stage;

public class NewMemberController {
    @FXML
    private TextField nameField;
    @FXML
    private TextField addressField;
    @FXML
    private TextField dobField;
    @FXML
    private TextField emailField;
    @FXML
    private TextField ssnField;
    @FXML
    private TextField memberField;
    @FXML
    private Button saveButton;
    @FXML
    private RadioButton externalButton;
    @FXML
    private RadioButton studentButton;
    @FXML
    private RadioButton professorButton;
     
    private static String currType;
    
    private List<Member> memberlist;
    
    public void setlist(List<Member> memberlist) {
      this.memberlist = memberlist;
    }
    
    @FXML
  public void initialize() {
        saveButton.setOnAction(event -> saveButtonClicked());
        memberlist = new ArrayList<>();
        externalButton.setOnAction(event -> externalButtonClicked());
        studentButton.setOnAction(event -> studentButtonClicked());
        professorButton.setOnAction(event -> professorButtonClicked());
    }
  
  public void externalButtonClicked() {
      currType = "external";
   }
  
    public void studentButtonClicked() {
      currType = "student";
   }
    
     public void professorButtonClicked() {
      currType = "professor";
   }
  
  @FXML
    private Date convertTextFieldToDate() {

        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        dateFormat.setLenient(false);
        Date date = null;
        boolean validDate = false;
        String dateString = dobField.getText();
        try {
            date = dateFormat.parse(dateString);
            System.out.println("Parsed Date: " + date);
            validDate = true;
            
            // Do something with the parsed date
        } catch (ParseException e) {
            System.out.println("Invalid date format. Please enter date of birth in MM/dd/yyyy format.");
            // Handle the parse exception
        }
    return date;
   }

    public void saveButtonClicked() {
        String name = nameField.getText();
        String address = addressField.getText();
        Date dob = convertTextFieldToDate();
        String email = emailField.getText();
        String ssn = ssnField.getText();
        String MemType = currType;
        String MemID = GetIDs.returnID("members.txt");
        if (name.equals("") || address.equals("") || email.equals("") || ssn.equals("") || MemType.equals("") || dob == null ) {
           System.out.println("Please Enter ALL Information \n");
        }
        else {
            

        String employeeInfo = MemID + "\t" + name + "\t" + address + "\t" + dob + "\t" + email + "\t" + ssn + "\t" + MemType + "\n";
        
        Member mem = new Member(name, address, dob, email, ssn, MemID, MemType);
        
        memberlist.add(mem);
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Scene7.fxml"));
        try {
            Parent root = loader.load();
            UpdateMemberController UMC = loader.getController();
            UMC.setlist(memberlist);
        } catch (IOException ex) {
            Logger.getLogger(NewMemberController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        try{
        SaveToFile.save(employeeInfo, "members.txt");
        String CheckoutString = String.format("%s\t0\t0\t0\t0\t0\n",MemID);
        SaveToFile.save(CheckoutString,"CheckedOutItems.txt");
        showSuccessAlert();
        } catch (Exception e) {
            showErrorAlert();
        }
       }
    }      

    private void showSuccessAlert() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText(null);
        alert.setContentText("New Member Successfully Saved to File.");
        alert.showAndWait();
    }

    private void showErrorAlert() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText("Failed to save member information.");
        alert.showAndWait();
    }

    

public void switchToScene1(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Scene1.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    // Other methods for switching scenes, etc.
}

