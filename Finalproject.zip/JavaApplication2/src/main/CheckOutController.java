package main;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;


public class CheckOutController {
    private List<Member> memberlist;
    @FXML
    private TextField collectionIDTextField;
    @FXML
    private Button checkoutButton;
    @FXML   
    private TextField MemberID;
    private String ID;
    
    private String collectionID;
    
 public void initialize() {
    checkoutButton.setOnAction(event -> checkoutButtonClicked());
    memberlist = new ArrayList<>();
        try {
            File members = new File("members.txt");

            if(members.exists()) {
                BufferedReader reader = new BufferedReader(new FileReader(members));
                String curr;
                while((curr = reader.readLine()) != null) {
                    String[] memberInfo = curr.split("\t");
                    String memID = memberInfo[0].strip();
                    String email = memberInfo[4];
                    String origDob = memberInfo[3];
                    String address = memberInfo[2];
                    String memberType = memberInfo[6];
                    String name = memberInfo[1];
                    String ssn = memberInfo[5];

                    Date newdob = new Date(0);
                    Member mem = new Member(name, address, newdob, email, ssn, memID, memberType);
                    memberlist.add(mem);
                }

                reader.close();
            }
        } catch (IOException e) {
            System.out.println("There was an error trying to update member " + MemberID.getText());
            e.printStackTrace();
        }
         for (Member mem : memberlist){
            System.out.println(mem.getMemberID());
            
        }
    }
 public void checkoutButtonClicked() {
     Member member = null;
     ID = MemberID.getText();
     for(Member mem: memberlist) {
       if (ID.equals(mem.getMemberID())) {
           member = mem;
       }
     }
     if (member == null) {
         System.out.println("There was no member found with member ID "+ ID);
     } else {
        boolean valid = false;

            int[] total = {0};
            boolean idExists = readCheckedOutItems(0, "-1", ID, member, total);

            if (idExists == true) {
                System.out.println("The member's currently checked out items are: ");
                for (int i = 0; i < 5; i++) {
                    String item = member.getCheckedOut(i);
                    if(!item.equals("0")) {
                        System.out.println(" " + member.getCheckedOut(i));
                    } else {
                        System.out.println("Empty");
                    }
                }

                ArrayList<String> itemList = new ArrayList<>();

                readCheckedOutItems(1, "-1", ID, member, total);

                if (total[0] < 5) {
                    int more = 5 - total[0];
                    String newItemID = checkoutNewItem();
                    readCheckedOutItems(1, newItemID, ID, member, total);
                } else {
                    showErrorAlert();
                    System.out.println("You already have the max amount of checked out items.");
                }
            } else {
                showErrorAlert2();
                System.out.println("The given member ID was not found: " + ID);
            } 
     }
 }
 
 private  String checkoutNewItem() {
        boolean valid = false;

        File collections = new File("Collectiondatabase.txt");
        String collID = "0";
        
        try {
            BufferedReader reader = new BufferedReader(new FileReader(collections));

            String curr;
            boolean found = false;

            while ((curr = reader.readLine()) != null) {
                String[] collectionInfo = curr.split(",");

                if(collectionInfo.length < 1) {
                    continue;
                }

                collID = collectionInfo[0];
                
                String isbn_sn = collectionInfo[1];
                String ItemID = collectionIDTextField.getText();
                if (ItemID.equals(isbn_sn)) {
                    found = true;
                    break;
                }
            }

            reader.close();
            return collID;
        } catch (IOException e) {
            System.out.println("There was an error reading the checked out items.");
            e.printStackTrace();
        }

        return collID;
    }
 
    private static boolean readCheckedOutItems(int toDo, String collID, String memberID, Member member, int[] total) {
        total[0] = 0;

        String curr;

        int id = Integer.parseInt(member.getMemberID());
        
        File temp = null;
        File checkedOutItems = null;
        boolean updated = false;
        boolean returnValue = false;

        try {
            temp = new File("tempCheckedOut.txt");
            checkedOutItems = new File("CheckedOutItems.txt");

            BufferedReader reader = new BufferedReader(new FileReader(checkedOutItems));
            BufferedWriter writer = new BufferedWriter(new FileWriter(temp));

            while ((curr = reader.readLine()) != null) {
                String[] currInfo = curr.split("\t");
                int memID = Integer.parseInt(currInfo[0]);

                if (toDo == 0 && id == memID) {
                    returnValue = true;
                }

                if (toDo == 1 && id == memID) {
                    for (int i = 1; i < 6; i++) {
                        if (!currInfo[i].equals("0")) {
                            total[0]++;
                        }
                    }
                }

                if (collID != "-1") {

                    if (memID == id) {
                        String content;

                        for (int i = 1; i < 6; i++) {
                            if (currInfo[i].equals("0")) {
                                currInfo[i] = collID;

                                member.setCheckedOut(i, collID);
                                
                                for(String value : currInfo) {
                                    writer.write(value + "\t");
                                }
                                updated = true;
                                writer.newLine();
                                break;
                            }
                        }
                    } else {
                        writer.write(curr);
                        writer.newLine();
                    }
                }
            }

            reader.close();
            writer.close();
            performFileOperations(temp, checkedOutItems, updated);
        } catch (IOException e) {
            System.out.println("There was an error trying to update checked out items for member " + id + "\n");
            e.printStackTrace();
        }

        return returnValue;
    }
 
 private static void performFileOperations(File temp, File checkedOutItems, boolean updated) {
        if(updated == true) {
            if (!checkedOutItems.delete()) {
                System.out.println("Could not delete file: " + checkedOutItems.getName());
            }

            if (!temp.renameTo(checkedOutItems)) {
                System.out.println("Could not rename file: " + temp.getName());
            }
        }
    }   
    
     public void switchToScene1(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Scene1.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
  private void showSuccessAlert() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText(null);
        alert.setContentText("Successfully Checked Out Item.");
        alert.showAndWait();
    }

    private void showErrorAlert() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText("Max amount of Items Checked Out.");
        alert.showAndWait();
    }
    
     private void showErrorAlert2() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText("Member ID not Found.");
        alert.showAndWait();
    }
}

