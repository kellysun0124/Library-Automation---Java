package main;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.RadioButton;
import javafx.stage.Stage;

public class NewEmployeeController {
    @FXML
    private TextField nameField;
    @FXML
    private TextField addressField;
    @FXML
    private TextField dobField;
    @FXML
    private TextField emailField;
    @FXML
    private TextField ssnField;
    @FXML
    private TextField empTypeField;
    @FXML
    private Button saveButton;
    @FXML
    private RadioButton librarianButton;
    @FXML
    private RadioButton technicianButton;
    
    private static String currType;

    @FXML
    public void initialize() {
        saveButton.setOnAction(event -> saveButtonClicked());
        librarianButton.setOnAction(event -> librarianButtonClicked());
        technicianButton.setOnAction(event -> technicianButtonClicked());
    }
    
    private void librarianButtonClicked() {
        currType = "librarian";
    }
    
    private void technicianButtonClicked() {
        currType = "technician";
    }

    public void saveButtonClicked() {
        String empNum = GetIDs.returnID("employees.txt");
        String name = nameField.getText();
        String address = addressField.getText();
        String dob = dobField.getText();
        String email = emailField.getText();
        String ssn = ssnField.getText();
        String empType = currType;

        String employeeInfo = empNum + "\t" + name + "\t" + address + "\t" + dob + "\t" + email + "\t" + ssn + "\t" + empType + "\n";

      try {
          SaveToFile.save(employeeInfo, "employees.txt");
          showSuccessAlert();
      } catch(Exception e) {
        showErrorAlert();
    }
    }

    private void showSuccessAlert() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText(null);
        alert.setContentText("New Employee Successfully Saved to File.");
        alert.showAndWait();
    }

    private void showErrorAlert() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText("Failed to save employee information.");
        alert.showAndWait();
    }

    

public void switchToScene1(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Scene1.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    // Other methods for switching scenes, etc.
}
