
package main;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class RemoveCollectionController {
    
    @FXML
    private TextField collectionIDField;
    @FXML
    private Button removeButton;
    
    public void initialize() {
        removeButton.setOnAction(event -> removeButtonClicked());
    }
    
    public void removeButtonClicked() {
      File myFile = new File("Collectiondatabase.txt");
        File tempFile = new File("temp.txt");
        try (BufferedReader reader = new BufferedReader(new FileReader(myFile));
                FileWriter writer = new FileWriter(tempFile)) {
            String collectionId = collectionIDField.getText();
            String lineToRemove = collectionId;
            String currentLine;
            boolean found = false;

            while ((currentLine = reader.readLine()) != null) {
                if (currentLine.startsWith(lineToRemove)) {
                    found = true;
                    continue;
                } else {
                    writer.write(currentLine + "\n"); // changed to "\n"
                }
            }

            if (!found) {
                System.out.println("Collection not found.");
            } else {
                System.out.println("Collection removed successfully.");
            }

            writer.close();
            reader.close();

            if (!myFile.delete()) {
                System.out.println("Could not delete the original file.");
            }
            else if (!tempFile.renameTo(myFile)) {
                System.out.println("Could not rename the temporary file.");
            }
            else{
            showSuccessAlert();
            }

        } catch (IOException e) {
            showErrorAlert();
            System.out.println("There was an error trying to remove the collection!");
            e.printStackTrace();
        }  
    }

            


    public void switchToScene1(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Scene1.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    
        private void showSuccessAlert() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText(null);
        alert.setContentText("Successfully Removed Collection.");
        alert.showAndWait();
    }

    private void showErrorAlert() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText("Failed to Remove Collection.");
        alert.showAndWait();
    }
}
    
