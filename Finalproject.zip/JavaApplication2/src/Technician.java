
import main.Collections;
import main.Employee;
import java.util.Date;

public class Technician extends Employee{
    public Technician (String name, String address, Date dateOfBirth, String email, String socialSecurityNumber, String empType, String employeeNumber){
        super(employeeNumber, name, address, dateOfBirth, email, socialSecurityNumber, empType);
    }
    //only need access collection to re-shelve things
    public String getCollectionID(Collections collection){
        return collection.getCollectionID();
    }
}

